// Theta SSO Provider
export function SSOProvider({className}: any) {
    return (
        <div className={className + "gap-4 flex flex-col"}>
            <hr />
            <p>Or Sign In With</p>
        </div>
    )
}